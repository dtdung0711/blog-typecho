/** hack js laguage pack */
//tinymce.ScriptLoader.load(tinymce.baseURL + '/langs.php');
